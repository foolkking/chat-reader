from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any

from . import TARGET_PROFILE

PROMPT = "## Prompt:"
RESPONSE = "## Response:"
DELIMITERS = {PROMPT, RESPONSE}
_META_RE = re.compile(r"^\*\*(User|Created|Updated|Exported|Link):\*\* (.*?)(?:  )?$")
_TIMESTAMP_RE = re.compile(
    r"^(?:Unknown|"
    r"\d{4}[/-]\d{1,2}[/-]\d{1,2}[ T]\d{1,2}:\d{2}(?::\d{2})?(?:\.\d+)?(?:\s*(?:Z|[+-]\d{2}:?\d{2}))?|"
    r"\d{1,2}[/-]\d{1,2}[/-]\d{4}[ T]\d{1,2}:\d{2}(?::\d{2})?(?:\s*(?:AM|PM))?"
    r")$",
    re.I,
)
_FENCE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")


@dataclass(frozen=True)
class ParsedMessage:
    role: str
    timestamp: str
    model: str | None
    body: str
    line_start: int


@dataclass(frozen=True)
class ParsedTranscript:
    title: str
    user: str
    created: str
    updated: str
    exported: str
    link_display: str
    link_value: str | None
    messages: list[ParsedMessage]


def normalize_lf(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


def is_timestamp_display(value: str) -> bool:
    return bool(_TIMESTAMP_RE.fullmatch(value.strip()))


def _parse_link(display: str) -> str | None:
    if display == "N/A":
        return None
    m = re.fullmatch(r"\[([^\]]+)\]\(([^)]+)\)", display)
    if not m or m.group(1) != m.group(2):
        raise ValueError("Link must be N/A or [URL](URL) with identical label/target")
    return m.group(1)


def _response_meta_valid(meta: str) -> bool:
    if " · " not in meta:
        return False
    timestamp, model = meta.split(" · ", 1)
    return is_timestamp_display(timestamp) and bool(model.strip())


def _prompt_meta_valid(meta: str) -> bool:
    return is_timestamp_display(meta)


def _is_structural_signature(lines: list[str], i: int, *, first_allowed: bool = False) -> bool:
    if i < 0 or i + 2 >= len(lines):
        return False
    heading = lines[i]
    if heading not in DELIMITERS:
        return False
    if not first_allowed and i > 0 and lines[i - 1] != "":
        return False
    if lines[i + 2] != "":
        return False
    meta = lines[i + 1]
    if heading == PROMPT:
        return _prompt_meta_valid(meta)
    return _response_meta_valid(meta)


def find_message_starts(lines: list[str], start: int) -> list[int]:
    starts: list[int] = []
    fence_char: str | None = None
    fence_len = 0
    i = start
    while i < len(lines):
        line = lines[i]
        fm = _FENCE_RE.match(line)
        if fm:
            token = fm.group(1)
            char = token[0]
            if fence_char is None:
                fence_char, fence_len = char, len(token)
            elif char == fence_char and len(token) >= fence_len and fm.group(2).strip() == "":
                fence_char, fence_len = None, 0
            i += 1
            continue
        if fence_char is None and _is_structural_signature(lines, i, first_allowed=(i == start)):
            starts.append(i)
            # The metadata and mandatory blank line cannot begin another block.
            i += 3
            continue
        i += 1
    return starts


def body_has_structural_collision(body: str) -> bool:
    lines = normalize_lf(body).split("\n")
    # Simulate the structural blank line immediately before a body.
    probe = [""] + lines
    return bool(find_message_starts(probe, 1))


def parse_transcript(text: str) -> ParsedTranscript:
    if "\r" in text:
        raise ValueError("target must use LF line endings")
    text = text.rstrip("\n") + "\n"
    lines = text.split("\n")
    if len(lines) < 11:
        raise ValueError("target too short")
    if not lines[0].startswith("# ") or lines[0].startswith("## "):
        raise ValueError("first line must be one H1 title")
    title = lines[0][2:]
    if not title:
        raise ValueError("empty title")
    if lines[1] != "":
        raise ValueError("expected blank line after title")

    expected = ["User", "Created", "Updated", "Exported", "Link"]
    values: dict[str, str] = {}
    for idx, key in enumerate(expected, start=2):
        m = _META_RE.match(lines[idx])
        if not m or m.group(1) != key:
            raise ValueError(f"expected metadata field {key} at line {idx+1}")
        value = m.group(2)
        if value == "":
            raise ValueError(f"metadata field {key} must not be empty")
        values[key] = value
    if lines[7] != "":
        raise ValueError("expected blank line after conversation metadata")
    link_value = _parse_link(values["Link"])

    starts = find_message_starts(lines, 8)
    if not starts:
        raise ValueError("no Prompt/Response message blocks")
    if starts[0] != 8:
        raise ValueError("unexpected content before first message")

    messages: list[ParsedMessage] = []
    for pos, start in enumerate(starts):
        end = starts[pos + 1] if pos + 1 < len(starts) else len(lines) - 1
        if start + 3 > end:
            raise ValueError(f"incomplete message block at line {start+1}")
        heading = lines[start]
        meta = lines[start + 1]
        if lines[start + 2] != "":
            raise ValueError(f"expected blank line before body at line {start+3}")
        body_lines = lines[start + 3:end]
        if pos + 1 < len(starts):
            if not body_lines or body_lines[-1] != "":
                raise ValueError(f"expected structural blank line before next block at line {end+1}")
            body_lines = body_lines[:-1]
        body = "\n".join(body_lines)
        if not body:
            raise ValueError(f"empty message body at line {start+1}")
        if heading == PROMPT:
            role = "user"
            timestamp = meta
            model = None
        else:
            role = "assistant"
            timestamp, model = meta.split(" · ", 1)
        messages.append(ParsedMessage(role, timestamp, model, body, start + 1))

    return ParsedTranscript(
        title=title,
        user=values["User"],
        created=values["Created"],
        updated=values["Updated"],
        exported=values["Exported"],
        link_display=values["Link"],
        link_value=link_value,
        messages=messages,
    )


def expected_message_body(msg: dict[str, Any]) -> str:
    body = normalize_lf(msg.get("body", ""))
    attachments = sorted(msg.get("attachments", []), key=lambda x: x["source_order"])
    markers = [f"[Attachment: {a['filename']}]" for a in attachments]
    if markers:
        marker_text = "\n\n".join(markers)
        if body:
            return body + "\n\n" + marker_text
        return marker_text
    return body


def _display(value: str | None, fallback: str) -> str:
    return value if value not in (None, "") else fallback


def render_transcript(candidate: dict[str, Any]) -> str:
    conv = candidate["conversation"]
    title = conv["title"]["value"]
    user = conv["user"]["value"]
    created = _display(conv["created"]["value"], "Unknown")
    updated = _display(conv["updated"]["value"], "Unknown")
    exported = _display(conv["exported"]["value"], "Unknown")
    link = conv["link"]["value"]
    link_display = "N/A" if link in (None, "") else f"[{link}]({link})"

    parts: list[str] = [
        f"# {title}",
        "",
        f"**User:** {user}  ",
        f"**Created:** {created}  ",
        f"**Updated:** {updated}  ",
        f"**Exported:** {exported}  ",
        f"**Link:** {link_display}",
        "",
    ]
    block_texts: list[str] = []
    for msg in candidate["messages"]:
        body = expected_message_body(msg)
        if body_has_structural_collision(body):
            raise ValueError("candidate body contains an unresolved structural delimiter signature")
        timestamp = _display(msg.get("timestamp"), "Unknown")
        if msg["role"] == "user":
            heading = PROMPT
            meta = timestamp
        else:
            heading = RESPONSE
            model = _display(msg.get("model"), "Unknown")
            meta = f"{timestamp} · {model}"
        block_texts.append(f"{heading}\n{meta}\n\n{body}")
    text = "\n".join(parts) + "\n" + "\n\n".join(block_texts) + "\n"
    parse_transcript(text)
    return text


def transcript_to_report(parsed: ParsedTranscript) -> dict[str, Any]:
    return {
        "profile": TARGET_PROFILE,
        "header": {
            "title": parsed.title,
            "user": parsed.user,
            "created": parsed.created,
            "updated": parsed.updated,
            "exported": parsed.exported,
            "link": parsed.link_value,
        },
        "messages": {
            "count": len(parsed.messages),
            "prompt_count": sum(m.role == "user" for m in parsed.messages),
            "response_count": sum(m.role == "assistant" for m in parsed.messages),
        },
    }
