"""Shared runtime for chat-transcript-normalizer."""

RUNTIME_NAME = "chat-transcript-normalizer-runtime"
RUNTIME_VERSION = "1.1.0"
TARGET_PROFILE = "chatgpt-markdown-transcript-v1"
CANDIDATE_SCHEMA = "chat-transcript-conversation-candidate"
CANDIDATE_SCHEMA_VERSION = "1.1.0"
ADAPTER_SCHEMA = "chat-transcript-source-adapter"
ADAPTER_SCHEMA_VERSION = "1.0.0"
