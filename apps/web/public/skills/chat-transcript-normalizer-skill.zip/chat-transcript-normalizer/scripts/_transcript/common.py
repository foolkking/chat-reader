from __future__ import annotations

import hashlib
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class TextSource:
    path: Path
    name: str
    raw: bytes
    text: str
    encoding: str
    sha256: str
    byte_size: int
    line_count: int


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def count_lines(text: str) -> int:
    if not text:
        return 0
    return len(text.splitlines())


def read_text_source(path: str | Path) -> TextSource:
    p = Path(path)
    if not p.is_file():
        raise ValueError(f"source is not a regular file: {p}")
    raw = p.read_bytes()
    encoding: str
    if raw.startswith(b"\xef\xbb\xbf"):
        encoding = "utf-8-sig"
        text = raw.decode("utf-8-sig")
    elif raw.startswith(b"\xff\xfe"):
        encoding = "utf-16-le"
        text = raw[2:].decode("utf-16-le")
    elif raw.startswith(b"\xfe\xff"):
        encoding = "utf-16-be"
        text = raw[2:].decode("utf-16-be")
    else:
        encoding = "utf-8"
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise UnicodeError("unsupported text encoding; v1 accepts UTF-8 or BOM-marked UTF-16") from exc
    return TextSource(
        path=p,
        name=p.name,
        raw=raw,
        text=text,
        encoding=encoding,
        sha256=sha256_bytes(raw),
        byte_size=len(raw),
        line_count=count_lines(text),
    )


def load_json(path: str | Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def json_bytes(value: Any, *, pretty: bool = False) -> bytes:
    if pretty:
        s = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)
    else:
        s = json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return (s + "\n").encode("utf-8")


def write_json_stdout(value: Any, *, pretty: bool = False) -> None:
    import sys
    sys.stdout.buffer.write(json_bytes(value, pretty=pretty))


def write_json_file(path: str | Path, value: Any, *, pretty: bool = False) -> None:
    Path(path).write_bytes(json_bytes(value, pretty=pretty))


def atomic_write_new(path: str | Path, data: bytes) -> None:
    target = Path(path)
    if target.exists():
        raise FileExistsError(f"output already exists: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        # Publish only if the destination is still absent. Hard-link creation is
        # atomic with respect to destination existence and avoids os.replace()
        # silently overwriting a file created after the initial existence check.
        os.link(tmp_name, target)
        os.unlink(tmp_name)
    except Exception:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass
        raise


def atomic_write_many_new(items: list[tuple[str | Path, bytes]]) -> None:
    """Publish multiple new files without overwriting existing destinations.

    All temporary files are written and fsynced first. Destinations are then created
    with hard links; if any publication fails, already-published destinations from
    this transaction are removed. Existing destination files are never overwritten.
    """
    targets = [Path(path) for path, _ in items]
    if len({str(x.resolve()) for x in targets}) != len(targets):
        raise ValueError("duplicate output paths in atomic transaction")
    for target in targets:
        if target.exists():
            raise FileExistsError(f"output already exists: {target}")
        target.parent.mkdir(parents=True, exist_ok=True)

    temps: list[tuple[Path, str]] = []
    published: list[Path] = []
    try:
        for (target, (_, data)) in zip(targets, items):
            fd, tmp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            temps.append((target, tmp_name))
        for target, tmp_name in temps:
            os.link(tmp_name, target)
            published.append(target)
        for _, tmp_name in temps:
            os.unlink(tmp_name)
    except Exception:
        for target in published:
            try:
                target.unlink()
            except FileNotFoundError:
                pass
        for _, tmp_name in temps:
            try:
                os.unlink(tmp_name)
            except FileNotFoundError:
                pass
        raise
