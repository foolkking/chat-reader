from __future__ import annotations

import re
from typing import Any

from . import CANDIDATE_SCHEMA, CANDIDATE_SCHEMA_VERSION, TARGET_PROFILE
from .common import TextSource
from .profile import body_has_structural_collision, normalize_lf

_ID_RE = re.compile(r"^MSG-CAND-[0-9]{4,}$")
_HASH_RE = re.compile(r"^[0-9a-f]{64}$")
_ALLOWED_RESULTS = {"NORMALIZED", "PARTIAL", "BLOCKED"}
_ALLOWED_BASES = {"source_title", "source_metadata", "source_filename", "fallback_anonymous", "synthetic_fallback", "unknown"}
_FIELD_BASES = {
    "title": {"source_title", "source_metadata", "source_filename", "synthetic_fallback"},
    "user": {"source_metadata", "fallback_anonymous"},
    "created": {"source_metadata", "unknown"},
    "updated": {"source_metadata", "unknown"},
    "exported": {"source_metadata", "unknown"},
    "link": {"source_metadata", "unknown"},
}
_ALLOWED_ATTACHMENT_BASES = {"source_attachment_metadata", "source_body_marker"}
_ALLOWED_FRAGMENT_KINDS = {"message", "body", "progress", "tool_call", "tool_result", "metadata", "attachment", "wrapper", "other"}
_ALLOWED_SOURCE_ROLES = {"user", "assistant", "tool", "system", "developer", "unknown"}
_ALLOWED_CONTRIBUTIONS = {"retained_body", "support", "removed_runtime"}
_ALLOWED_TRANSFORMS = {
    "remove_outer_wrapper", "remove_runtime_noise", "remove_transport_duplicate", "remove_empty_shell",
    "container_decode", "role_normalization", "attachment_marker_normalization", "preserve_verbatim",
    "turn_reconstruction", "tool_context_fold", "progress_fold",
}
_ALLOWED_REASONS = {"runtime_noise", "transport_duplicate", "empty_shell", "source_wrapper", "unsupported_nonconversation_metadata", "other"}
_ALLOWED_CONFIDENCE = {"high", "medium"}
_ALLOWED_UNRESOLVED = {"boundary", "role", "order", "branch", "version", "missing_body", "unsupported_role", "representation", "tool_linkage", "other"}
_ALLOWED_UNRESOLVED_IMPACT = {"local", "material"}
_ALLOWED_DISPOSITIONS = {"external_audit", "blocks_conversion"}


def _single_line(value: Any, field: str, errors: list[str], *, allow_null: bool = False) -> None:
    if value is None and allow_null:
        return
    if not isinstance(value, str) or not value:
        errors.append(f"{field} must be a non-empty string")
        return
    if "\n" in value or "\r" in value:
        errors.append(f"{field} must be single-line")


def _validate_locator(locator: Any, field: str, errors: list[str], source: TextSource | None) -> None:
    if not isinstance(locator, dict):
        errors.append(f"{field} must be an object")
        return
    has_any = False
    a, b = locator.get("line_start"), locator.get("line_end")
    if a is not None or b is not None:
        has_any = True
        if not isinstance(a, int) or not isinstance(b, int) or a < 1 or b < a:
            errors.append(f"{field} line range invalid")
        elif source is not None and b > source.line_count:
            errors.append(f"{field} line range outside source")
    cs, ce = locator.get("char_start"), locator.get("char_end")
    if cs is not None or ce is not None:
        has_any = True
        if not isinstance(cs, int) or not isinstance(ce, int) or cs < 0 or ce < cs:
            errors.append(f"{field} char range invalid")
        elif source is not None and ce > len(source.text):
            errors.append(f"{field} char range outside source")
    for key in ("json_pointer", "html_path"):
        value = locator.get(key)
        if value is not None:
            has_any = True
            _single_line(value, f"{field}.{key}", errors)
    if not has_any:
        errors.append(f"{field} must contain a line/char/json/html locator")


def validate_candidate(candidate: Any, source: TextSource | None = None, *, require_serializable: bool = True) -> list[str]:
    errors: list[str] = []
    if not isinstance(candidate, dict):
        return ["candidate must be a JSON object"]
    if candidate.get("schema") != CANDIDATE_SCHEMA:
        errors.append("unsupported candidate schema")
    if candidate.get("schema_version") != CANDIDATE_SCHEMA_VERSION:
        errors.append("unsupported candidate schema_version")
    if candidate.get("target_profile") != TARGET_PROFILE:
        errors.append("unsupported target_profile")
    result = candidate.get("result")
    if result not in _ALLOWED_RESULTS:
        errors.append("result must be NORMALIZED, PARTIAL, or BLOCKED")

    src = candidate.get("source")
    if not isinstance(src, dict):
        errors.append("source must be an object")
    else:
        _single_line(src.get("name"), "source.name", errors)
        if not isinstance(src.get("sha256"), str) or not _HASH_RE.fullmatch(src.get("sha256", "")):
            errors.append("source.sha256 must be 64 lowercase hex")
        if not isinstance(src.get("byte_size"), int) or src.get("byte_size", -1) < 0:
            errors.append("source.byte_size must be a non-negative integer")
        _single_line(src.get("encoding"), "source.encoding", errors)
        if not isinstance(src.get("line_count"), int) or src.get("line_count", -1) < 0:
            errors.append("source.line_count must be a non-negative integer")
        if source is not None:
            if src.get("name") != source.name: errors.append("source.name binding mismatch")
            if src.get("sha256") != source.sha256: errors.append("source.sha256 binding mismatch")
            if src.get("byte_size") != source.byte_size: errors.append("source.byte_size binding mismatch")
            if src.get("encoding") != source.encoding: errors.append("source.encoding binding mismatch")
            if src.get("line_count") != source.line_count: errors.append("source.line_count binding mismatch")

    adapter = candidate.get("adapter")
    if adapter is not None:
        if not isinstance(adapter, dict):
            errors.append("adapter must be an object when present")
        else:
            _single_line(adapter.get("name"), "adapter.name", errors)
            _single_line(adapter.get("status"), "adapter.status", errors)

    conv = candidate.get("conversation")
    if not isinstance(conv, dict):
        errors.append("conversation must be an object")
    else:
        for key in ("title", "user", "created", "updated", "exported", "link"):
            item = conv.get(key)
            if not isinstance(item, dict):
                errors.append(f"conversation.{key} must be an object")
                continue
            basis = item.get("basis")
            if basis not in _ALLOWED_BASES or basis not in _FIELD_BASES[key]:
                errors.append(f"conversation.{key}.basis invalid")
            if key in ("title", "user"):
                _single_line(item.get("value"), f"conversation.{key}.value", errors)
            else:
                value = item.get("value")
                if value is not None:
                    _single_line(value, f"conversation.{key}.value", errors)
                    if key == "link" and isinstance(value, str) and any(c in value for c in "])"):
                        errors.append("conversation.link.value cannot be serialized safely in v1 Markdown link form")

    messages = candidate.get("messages")
    ids: set[str] = set()
    if not isinstance(messages, list):
        errors.append("messages must be an array")
        messages = []
    if result in {"NORMALIZED", "PARTIAL"} and not messages:
        errors.append("serializable candidate must contain at least one message")
    for idx, msg in enumerate(messages):
        p = f"messages[{idx}]"
        if not isinstance(msg, dict):
            errors.append(f"{p} must be an object")
            continue
        cid = msg.get("candidate_id")
        if not isinstance(cid, str) or not _ID_RE.fullmatch(cid):
            errors.append(f"{p}.candidate_id invalid")
        elif cid in ids:
            errors.append(f"{p}.candidate_id duplicated")
        else:
            ids.add(cid)
        role = msg.get("role")
        if role not in {"user", "assistant"}:
            errors.append(f"{p}.role must be user or assistant")
        ts = msg.get("timestamp")
        if ts is not None: _single_line(ts, f"{p}.timestamp", errors)
        model = msg.get("model")
        if role == "user" and model is not None:
            errors.append(f"{p}.model must be null for user")
        if model is not None: _single_line(model, f"{p}.model", errors)
        body = msg.get("body")
        if not isinstance(body, str):
            errors.append(f"{p}.body must be a string")
            body = ""
        body_lf = normalize_lf(body)
        if body_lf.startswith("\n") or body_lf.endswith("\n"):
            errors.append(f"{p}.body must not contain outer blank-line newlines")
        if body_has_structural_collision(body_lf):
            errors.append(f"{p}.body has an unresolved structural delimiter signature")

        attachments = msg.get("attachments")
        if not isinstance(attachments, list):
            errors.append(f"{p}.attachments must be an array")
            attachments = []
        orders: set[int] = set()
        for j, att in enumerate(attachments):
            ap = f"{p}.attachments[{j}]"
            if not isinstance(att, dict):
                errors.append(f"{ap} must be an object")
                continue
            filename = att.get("filename")
            _single_line(filename, f"{ap}.filename", errors)
            if isinstance(filename, str) and ("/" in filename or "\\" in filename or filename in {".", ".."}):
                errors.append(f"{ap}.filename must be basename-like")
            if att.get("basis") not in _ALLOWED_ATTACHMENT_BASES:
                errors.append(f"{ap}.basis invalid")
            order = att.get("source_order")
            if not isinstance(order, int) or order <= 0:
                errors.append(f"{ap}.source_order must be positive integer")
            elif order in orders:
                errors.append(f"{ap}.source_order duplicated")
            else:
                orders.add(order)
            if isinstance(filename, str) and f"[Attachment: {filename}]" in body_lf.split("\n"):
                errors.append(f"{ap} duplicates a literal attachment marker already retained in body")
        if body == "" and not attachments:
            errors.append(f"{p} has empty body and no attachments")

        frags = msg.get("source_fragments")
        if not isinstance(frags, list) or not frags:
            errors.append(f"{p}.source_fragments must be a non-empty array")
            frags = []
        frag_ids: set[str] = set()
        frag_roles: list[str] = []
        for j, frag in enumerate(frags):
            fp = f"{p}.source_fragments[{j}]"
            if not isinstance(frag, dict):
                errors.append(f"{fp} must be an object")
                continue
            fid = frag.get("fragment_id")
            if not isinstance(fid, str) or not fid:
                errors.append(f"{fp}.fragment_id invalid")
            elif fid in frag_ids:
                errors.append(f"{fp}.fragment_id duplicated within message")
            else:
                frag_ids.add(fid)
            srole = frag.get("source_role")
            if srole not in _ALLOWED_SOURCE_ROLES:
                errors.append(f"{fp}.source_role invalid")
            else:
                frag_roles.append(srole)
            if frag.get("kind") not in _ALLOWED_FRAGMENT_KINDS:
                errors.append(f"{fp}.kind invalid")
            if frag.get("contribution") not in _ALLOWED_CONTRIBUTIONS:
                errors.append(f"{fp}.contribution invalid")
            if frag.get("adapter_fragment_id") is not None:
                _single_line(frag.get("adapter_fragment_id"), f"{fp}.adapter_fragment_id", errors)
            _validate_locator(frag.get("locator"), f"{fp}.locator", errors, source)

        reconstruction = msg.get("reconstruction")
        if not isinstance(reconstruction, dict):
            errors.append(f"{p}.reconstruction must be an object")
        else:
            mode = reconstruction.get("mode")
            if mode not in {"direct", "assistant_execution_turn"}:
                errors.append(f"{p}.reconstruction.mode invalid")
            if reconstruction.get("confidence") not in _ALLOWED_CONFIDENCE:
                errors.append(f"{p}.reconstruction.confidence invalid")
            evidence = reconstruction.get("evidence")
            if not isinstance(evidence, list) or not evidence or any(not isinstance(x, str) or not x for x in evidence):
                errors.append(f"{p}.reconstruction.evidence must be a non-empty string array")
            source_ids = reconstruction.get("source_fragment_ids")
            if not isinstance(source_ids, list) or set(source_ids) != frag_ids or len(source_ids) != len(frag_ids):
                errors.append(f"{p}.reconstruction.source_fragment_ids must exactly cover message source_fragments")
            if mode == "assistant_execution_turn":
                if role != "assistant":
                    errors.append(f"{p}.assistant_execution_turn requires assistant output role")
                if any(r not in {"assistant", "tool"} for r in frag_roles):
                    errors.append(f"{p}.assistant_execution_turn may only fold assistant/tool source fragments")
                if "assistant" not in frag_roles or len(frags) < 2:
                    errors.append(f"{p}.assistant_execution_turn requires at least two fragments including assistant")
            elif mode == "direct":
                if role == "user" and any(r != "user" for r in frag_roles):
                    errors.append(f"{p}.direct user reconstruction may only use user source fragments")
                if role == "assistant" and any(r != "assistant" for r in frag_roles):
                    errors.append(f"{p}.direct assistant reconstruction may only use assistant source fragments")

        transforms = msg.get("transformations")
        if not isinstance(transforms, list):
            errors.append(f"{p}.transformations must be an array")
        else:
            for t in transforms:
                if t not in _ALLOWED_TRANSFORMS:
                    errors.append(f"{p}.transformations contains invalid code {t!r}")

    removed = candidate.get("removed_spans")
    if not isinstance(removed, list):
        errors.append("removed_spans must be an array")
        removed = []
    removal_ids: set[str] = set()
    for idx, rem in enumerate(removed):
        p = f"removed_spans[{idx}]"
        if not isinstance(rem, dict):
            errors.append(f"{p} must be an object")
            continue
        rid = rem.get("removal_id")
        if not isinstance(rid, str) or not rid:
            errors.append(f"{p}.removal_id invalid")
        elif rid in removal_ids:
            errors.append(f"{p}.removal_id duplicated")
        else:
            removal_ids.add(rid)
        _validate_locator(rem.get("locator"), f"{p}.locator", errors, source)
        if rem.get("reason") not in _ALLOWED_REASONS:
            errors.append(f"{p}.reason invalid")
        if rem.get("confidence") not in _ALLOWED_CONFIDENCE:
            errors.append(f"{p}.confidence must be high or medium")

    unresolved = candidate.get("unresolved")
    if not isinstance(unresolved, list):
        errors.append("unresolved must be an array")
        unresolved = []
    unresolved_ids: set[str] = set()
    for idx, issue in enumerate(unresolved):
        p = f"unresolved[{idx}]"
        if not isinstance(issue, dict):
            errors.append(f"{p} must be an object")
            continue
        uid = issue.get("issue_id")
        if not isinstance(uid, str) or not uid:
            errors.append(f"{p}.issue_id invalid")
        elif uid in unresolved_ids:
            errors.append(f"{p}.issue_id duplicated")
        else:
            unresolved_ids.add(uid)
        if issue.get("kind") not in _ALLOWED_UNRESOLVED:
            errors.append(f"{p}.kind invalid")
        _single_line(issue.get("description"), f"{p}.description", errors)
        if issue.get("impact") not in _ALLOWED_UNRESOLVED_IMPACT:
            errors.append(f"{p}.impact invalid")
        if issue.get("disposition") not in _ALLOWED_DISPOSITIONS:
            errors.append(f"{p}.disposition invalid")
        excerpt = issue.get("excerpt")
        if excerpt is not None and (not isinstance(excerpt, str) or len(excerpt) > 2000):
            errors.append(f"{p}.excerpt must be a string of at most 2000 characters")
        _validate_locator(issue.get("locator"), f"{p}.locator", errors, source)

    acc = candidate.get("source_accounting")
    if not isinstance(acc, dict):
        errors.append("source_accounting must be an object")
    else:
        if acc.get("resolution_status") != result:
            errors.append("source_accounting.resolution_status must equal candidate result")
        if acc.get("retained_message_count") != len(messages):
            errors.append("source_accounting.retained_message_count mismatch")
        if acc.get("removed_span_count") != len(removed):
            errors.append("source_accounting.removed_span_count mismatch")
        if acc.get("unresolved_count") != len(unresolved):
            errors.append("source_accounting.unresolved_count mismatch")
        for key in ("confirmed_message_count", "retained_message_count", "whole_messages_removed", "unresolved_message_count", "removed_span_count", "transport_duplicate_count", "unresolved_count"):
            if not isinstance(acc.get(key), int) or acc.get(key, -1) < 0:
                errors.append(f"source_accounting.{key} must be non-negative integer")
        limitations = acc.get("limitations")
        if not isinstance(limitations, list):
            errors.append("source_accounting.limitations must be an array")
        elif any(not isinstance(x, str) or not x for x in limitations):
            errors.append("source_accounting.limitations entries must be non-empty strings")
        confirmed = acc.get("confirmed_message_count")
        retained = acc.get("retained_message_count")
        removed_messages = acc.get("whole_messages_removed")
        unresolved_messages = acc.get("unresolved_message_count")
        if all(isinstance(x, int) for x in (confirmed, retained, removed_messages, unresolved_messages)):
            if retained + removed_messages + unresolved_messages != confirmed:
                errors.append("source_accounting confirmed/retained/removed/unresolved message counts do not reconcile")
        duplicate_count = acc.get("transport_duplicate_count")
        removed_span_count = acc.get("removed_span_count")
        if isinstance(duplicate_count, int) and isinstance(removed_span_count, int) and duplicate_count > removed_span_count + (removed_messages if isinstance(removed_messages, int) else 0):
            errors.append("source_accounting.transport_duplicate_count exceeds all recorded removals")
        if require_serializable and acc.get("complete") is not True:
            errors.append("source_accounting.complete must be true for serialization")

    if result == "NORMALIZED" and unresolved:
        errors.append("NORMALIZED candidate must have no unresolved issues")
    if result == "PARTIAL":
        if not unresolved:
            errors.append("PARTIAL candidate must contain at least one unresolved issue")
        for issue in unresolved:
            if isinstance(issue, dict) and (issue.get("impact") != "local" or issue.get("disposition") != "external_audit"):
                errors.append("PARTIAL candidate unresolved issues must be local and external_audit")
    if result == "BLOCKED":
        if not unresolved:
            errors.append("BLOCKED candidate must explain at least one unresolved issue")
        if unresolved and not any(isinstance(i, dict) and (i.get("impact") == "material" or i.get("disposition") == "blocks_conversion") for i in unresolved):
            errors.append("BLOCKED candidate requires a material or blocks_conversion unresolved issue")
    if require_serializable and result == "BLOCKED":
        errors.append("BLOCKED candidate is not serializable")
    return errors
