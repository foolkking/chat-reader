from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from .adapters import adapt_source, compact_adapter_summary
from .common import TextSource
from .profile import parse_transcript

_TIMESTAMP_HINT = re.compile(r"(?:\d{4}[/-]\d{1,2}[/-]\d{1,2}|\d{1,2}[/-]\d{1,2}[/-]\d{4})[ T]\d{1,2}:\d{2}(?::\d{2})?")
_ROLE_LINE = re.compile(r"^(?:User|Human|Prompt|Question|Assistant|ChatGPT|Claude|Gemini|Response|Answer|System|Developer|Tool|用户|AI助手)\s*:\s*$", re.I)
_ATTACHMENT = re.compile(r"^\[Attachment:\s*(.+?)\]\s*$")


def inspect_source(source: TextSource) -> tuple[dict[str, Any], dict[str, Any]]:
    lines = source.text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    prompt = []
    response = []
    roles = []
    attachments = []
    timestamps = []
    for i, line in enumerate(lines, start=1):
        if line == "## Prompt:":
            prompt.append({"line": i, "text": line})
        if line == "## Response:":
            response.append({"line": i, "text": line})
        if _ROLE_LINE.match(line):
            roles.append({"line": i, "text": line[:200]})
        m = _ATTACHMENT.match(line)
        if m:
            attachments.append({"line": i, "filename": m.group(1)})
        if _TIMESTAMP_HINT.search(line):
            timestamps.append({"line": i, "text": line[:200]})

    stripped = source.text.lstrip()
    looks_json = False
    if stripped.startswith("{") or stripped.startswith("["):
        try:
            json.loads(source.text)
            looks_json = True
        except Exception:
            pass
    low = source.text[:4096].lower()
    looks_html = "<html" in low or "<!doctype html" in low or "data-message-author-role" in low

    target_status = "no_match"
    target_summary = None
    try:
        if source.encoding != "utf-8":
            raise ValueError("target profile requires UTF-8 without BOM")
        parsed = parse_transcript(source.text)
        target_status = "match"
        target_summary = {
            "title": parsed.title,
            "message_count": len(parsed.messages),
            "prompt_count": sum(m.role == "user" for m in parsed.messages),
            "response_count": sum(m.role == "assistant" for m in parsed.messages),
        }
    except Exception:
        if prompt or response:
            target_status = "ambiguous"

    header: dict[str, Any] = {}
    for i, line in enumerate(lines[:80], start=1):
        if i == 1 and line.startswith("# ") and not line.startswith("## "):
            header["title"] = {"line": i, "value": line[2:]}
        for key in ("User", "Created", "Updated", "Exported", "Link"):
            prefix = f"**{key}:** "
            if line.startswith(prefix):
                header[key.lower()] = {"line": i, "value": line[len(prefix):].rstrip()}

    adapter, attempts = adapt_source(source)
    report = {
        "report_schema": "chat-transcript-source-inspection",
        "report_version": "1.1.0",
        "status": "ok",
        "source": {
            "name": source.name,
            "sha256": source.sha256,
            "byte_size": source.byte_size,
            "encoding": source.encoding,
            "line_count": source.line_count,
        },
        "format_hints": {
            "extension": Path(source.name).suffix.lower(),
            "looks_like_json": looks_json,
            "looks_like_html": looks_html,
            "target_profile": target_status,
            "target_summary": target_summary,
        },
        "source_adapter": compact_adapter_summary(adapter),
        "adapter_attempts": [compact_adapter_summary(x) for x in attempts],
        "candidate_markers": {
            "prompt_headings": prompt,
            "response_headings": response,
            "role_like_lines": roles,
            "attachment_markers": attachments,
            "timestamp_like_lines": timestamps,
        },
        "header_candidates": header,
        "findings": list(adapter.get("findings", [])),
    }
    return report, adapter
