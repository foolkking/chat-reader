from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from html.parser import HTMLParser
import json
import re
from typing import Any

from . import ADAPTER_SCHEMA, ADAPTER_SCHEMA_VERSION
from .common import TextSource
from .profile import DELIMITERS, find_message_starts, normalize_lf, parse_transcript

_ROLE_LINE = re.compile(r"^(User|Human|Prompt|Question|Assistant|ChatGPT|Claude|Gemini|Response|Answer|System|Developer|Tool|用户|AI助手)\s*:\s*$", re.I)
_FENCE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
_ATTACHMENT = re.compile(r"^\[Attachment:\s*(.+?)\]\s*$")


def _role_alias(label: str) -> str:
    x = label.strip().lower()
    if x in {"user", "human", "prompt", "question", "用户"}:
        return "user"
    if x in {"assistant", "chatgpt", "claude", "gemini", "response", "answer", "ai助手"}:
        return "assistant"
    if x == "tool":
        return "tool"
    if x == "system":
        return "system"
    if x == "developer":
        return "developer"
    return "unknown"


def _epoch_display(value: Any) -> str | None:
    if not isinstance(value, (int, float)):
        return None
    try:
        dt = datetime.fromtimestamp(float(value), tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None
    return dt.isoformat().replace("+00:00", "Z")


def _base_report(source: TextSource, name: str, status: str, confidence: str) -> dict[str, Any]:
    return {
        "schema": ADAPTER_SCHEMA,
        "schema_version": ADAPTER_SCHEMA_VERSION,
        "source": {
            "name": source.name,
            "sha256": source.sha256,
            "byte_size": source.byte_size,
            "encoding": source.encoding,
            "line_count": source.line_count,
        },
        "adapter": {"name": name, "status": status, "confidence": confidence},
        "conversation_metadata": {},
        "fragments": [],
        "turn_groups": [],
        "findings": [],
    }


def _turn_groups(fragments: list[dict[str, Any]], *, high_confidence: bool = False) -> list[dict[str, Any]]:
    groups: list[dict[str, Any]] = []
    i = 0
    gid = 1
    while i < len(fragments):
        f = fragments[i]
        role = f.get("source_role")
        if role == "user":
            groups.append({
                "group_id": f"TURN-GROUP-{gid:04d}",
                "suggested_role": "user",
                "reconstruction": "direct",
                "fragment_ids": [f["fragment_id"]],
                "confidence": "high" if high_confidence else "medium",
                "evidence": ["explicit_source_role"],
            })
            gid += 1
            i += 1
            continue
        if role in {"assistant", "tool"}:
            j = i
            chunk: list[dict[str, Any]] = []
            while j < len(fragments) and fragments[j].get("source_role") in {"assistant", "tool"}:
                chunk.append(fragments[j])
                j += 1
            has_assistant = any(x.get("source_role") == "assistant" for x in chunk)
            has_tool = any(x.get("source_role") == "tool" for x in chunk)
            if has_assistant:
                mode = "assistant_execution_turn" if has_tool or len(chunk) > 1 else "direct"
                ev = ["contiguous_non_user_execution_span", "explicit_source_roles"]
                if high_confidence:
                    ev.append("native_branch_order")
                groups.append({
                    "group_id": f"TURN-GROUP-{gid:04d}",
                    "suggested_role": "assistant",
                    "reconstruction": mode,
                    "fragment_ids": [x["fragment_id"] for x in chunk],
                    "confidence": "high" if high_confidence else "medium",
                    "evidence": ev,
                })
                gid += 1
            i = j
            continue
        i += 1
    return groups


def adapt_target_profile(source: TextSource) -> dict[str, Any] | None:
    try:
        parsed = parse_transcript(source.text)
    except Exception:
        return None
    r = _base_report(source, "target_profile", "recognized", "high")
    r["conversation_metadata"] = {
        "title": parsed.title,
        "user": parsed.user,
        "created": parsed.created,
        "updated": parsed.updated,
        "exported": parsed.exported,
        "link": parsed.link_value,
    }
    for n, msg in enumerate(parsed.messages, start=1):
        r["fragments"].append({
            "fragment_id": f"ADAPT-{n:04d}",
            "source_role": msg.role,
            "kind": "message",
            "timestamp": msg.timestamp,
            "model": msg.model,
            "body": msg.body,
            "locator": {"line_start": msg.line_start},
        })
    r["turn_groups"] = _turn_groups(r["fragments"], high_confidence=True)
    return r


def _extract_json_content(message: dict[str, Any]) -> str:
    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, dict):
        parts = content.get("parts")
        if isinstance(parts, list):
            out: list[str] = []
            for part in parts:
                if isinstance(part, str):
                    out.append(part)
                elif isinstance(part, dict):
                    if isinstance(part.get("text"), str):
                        out.append(part["text"])
                    elif isinstance(part.get("content"), str):
                        out.append(part["content"])
            return "\n".join(x for x in out if x != "")
        if isinstance(content.get("text"), str):
            return content["text"]
    return ""


def adapt_chatgpt_json(source: TextSource) -> dict[str, Any] | None:
    stripped = source.text.lstrip()
    if not (stripped.startswith("{") or stripped.startswith("[")):
        return None
    try:
        data = json.loads(source.text)
    except Exception:
        return None

    obj: Any = data
    if isinstance(data, list):
        if len(data) != 1 or not isinstance(data[0], dict):
            r = _base_report(source, "chatgpt_json", "partial", "high")
            r["findings"].append({"severity": "warning", "code": "multiple_or_zero_conversations", "detail": "JSON contains multiple or zero top-level conversations; select one conversation before conversion."})
            return r
        obj = data[0]
    if not isinstance(obj, dict):
        return None

    fragments: list[dict[str, Any]] = []
    r = _base_report(source, "chatgpt_json", "recognized", "high")
    r["conversation_metadata"] = {
        "title": obj.get("title") if isinstance(obj.get("title"), str) else None,
        "user": None,
        "created": _epoch_display(obj.get("create_time")),
        "updated": _epoch_display(obj.get("update_time")),
        "exported": None,
        "link": None,
    }

    mapping = obj.get("mapping")
    current_node = obj.get("current_node")
    if isinstance(mapping, dict) and mapping:
        ordered_ids: list[str] = []
        if isinstance(current_node, str) and current_node in mapping:
            seen: set[str] = set()
            node_id: str | None = current_node
            while node_id and node_id not in seen and node_id in mapping:
                seen.add(node_id)
                ordered_ids.append(node_id)
                parent = mapping[node_id].get("parent") if isinstance(mapping[node_id], dict) else None
                node_id = parent if isinstance(parent, str) else None
            ordered_ids.reverse()
        else:
            def k(item: tuple[str, Any]) -> tuple[float, str]:
                node_id, node = item
                msg = node.get("message") if isinstance(node, dict) else None
                t = msg.get("create_time") if isinstance(msg, dict) else None
                return (float(t) if isinstance(t, (int, float)) else float("inf"), node_id)
            ordered_ids = [x[0] for x in sorted(mapping.items(), key=k)]
            r["findings"].append({"severity": "warning", "code": "missing_current_node", "detail": "No usable current_node; adapter used message create_time/order as a provisional sequence."})
            r["adapter"]["status"] = "partial"
            r["adapter"]["confidence"] = "medium"

        n = 1
        for node_id in ordered_ids:
            node = mapping.get(node_id)
            msg = node.get("message") if isinstance(node, dict) else None
            if not isinstance(msg, dict):
                continue
            author = msg.get("author")
            role = author.get("role") if isinstance(author, dict) else None
            if not isinstance(role, str):
                role = "unknown"
            body = _extract_json_content(msg)
            metadata = msg.get("metadata") if isinstance(msg.get("metadata"), dict) else {}
            model = metadata.get("model_slug") or metadata.get("default_model_slug")
            if not isinstance(model, str):
                model = None
            fragments.append({
                "fragment_id": f"ADAPT-{n:04d}",
                "source_role": role.lower(),
                "kind": "tool_result" if role.lower() == "tool" else "message",
                "timestamp": _epoch_display(msg.get("create_time")),
                "model": model,
                "body": body,
                "locator": {"json_pointer": f"/mapping/{node_id}/message"},
                "native": {"node_id": node_id, "parent": node.get("parent") if isinstance(node, dict) else None},
            })
            n += 1
    elif isinstance(obj.get("messages"), list):
        for n, msg in enumerate(obj["messages"], start=1):
            if not isinstance(msg, dict):
                continue
            role = msg.get("role")
            if not isinstance(role, str):
                role = "unknown"
            body = msg.get("content") if isinstance(msg.get("content"), str) else _extract_json_content(msg)
            fragments.append({
                "fragment_id": f"ADAPT-{n:04d}",
                "source_role": role.lower(),
                "kind": "tool_result" if role.lower() == "tool" else "message",
                "timestamp": msg.get("timestamp") if isinstance(msg.get("timestamp"), str) else None,
                "model": msg.get("model") if isinstance(msg.get("model"), str) else None,
                "body": body,
                "locator": {"json_pointer": f"/messages/{n-1}"},
            })
        r["adapter"]["confidence"] = "medium"
    else:
        return None

    if not fragments:
        r["adapter"]["status"] = "partial"
        r["findings"].append({"severity": "warning", "code": "no_message_fragments", "detail": "JSON shape was recognized but no message fragments were recoverable."})
    r["fragments"] = fragments
    r["turn_groups"] = _turn_groups(fragments, high_confidence=isinstance(mapping, dict) and isinstance(current_node, str))
    return r


def _fence_states(lines: list[str]) -> list[bool]:
    states: list[bool] = []
    fence_char: str | None = None
    fence_len = 0
    for line in lines:
        states.append(fence_char is not None)
        m = _FENCE_RE.match(line)
        if not m:
            continue
        token = m.group(1)
        char = token[0]
        if fence_char is None:
            fence_char, fence_len = char, len(token)
        elif char == fence_char and len(token) >= fence_len and m.group(2).strip() == "":
            fence_char, fence_len = None, 0
    return states


def adapt_markdown(source: TextSource) -> dict[str, Any] | None:
    text = normalize_lf(source.text)
    lines = text.split("\n")
    starts = find_message_starts(lines, 0)
    if not starts:
        return None
    r = _base_report(source, "markdown", "recognized", "medium")
    meta: dict[str, Any] = {}
    for i, line in enumerate(lines[:80], start=1):
        if i == 1 and line.startswith("# ") and not line.startswith("## "):
            meta["title"] = line[2:]
        for key in ("User", "Created", "Updated", "Exported", "Link"):
            prefix = f"**{key}:** "
            if line.startswith(prefix):
                meta[key.lower()] = line[len(prefix):].rstrip()
    r["conversation_metadata"] = meta
    for n, start in enumerate(starts, start=1):
        end = starts[n] if n < len(starts) else len(lines)
        heading = lines[start]
        meta_line = lines[start + 1]
        body_start = start + 3
        body_end = end
        if body_end > body_start and lines[body_end - 1] == "":
            body_end -= 1
        body = "\n".join(lines[body_start:body_end])
        if heading == "## Prompt:":
            role, timestamp, model = "user", meta_line, None
        else:
            timestamp, model = meta_line.split(" · ", 1)
            role = "assistant"
        r["fragments"].append({
            "fragment_id": f"ADAPT-{n:04d}",
            "source_role": role,
            "kind": "message",
            "timestamp": timestamp,
            "model": model,
            "body": body,
            "locator": {"line_start": start + 1, "line_end": max(start + 1, body_end)},
        })
    r["turn_groups"] = _turn_groups(r["fragments"], high_confidence=False)
    return r


def adapt_plain_text(source: TextSource) -> dict[str, Any] | None:
    text = normalize_lf(source.text)
    lines = text.split("\n")
    in_fence = _fence_states(lines)
    starts: list[tuple[int, str]] = []
    for i, line in enumerate(lines):
        if in_fence[i]:
            continue
        m = _ROLE_LINE.match(line)
        if m:
            starts.append((i, _role_alias(m.group(1))))
    if not starts:
        return None
    r = _base_report(source, "plain_text", "recognized", "medium")
    for n, (start, role) in enumerate(starts, start=1):
        end = starts[n][0] if n < len(starts) else len(lines)
        body_lines = lines[start + 1:end]
        while body_lines and body_lines[0] == "":
            body_lines.pop(0)
        while body_lines and body_lines[-1] == "":
            body_lines.pop()
        body = "\n".join(body_lines)
        r["fragments"].append({
            "fragment_id": f"ADAPT-{n:04d}",
            "source_role": role,
            "kind": "tool_result" if role == "tool" else "message",
            "timestamp": None,
            "model": None,
            "body": body,
            "locator": {"line_start": start + 1, "line_end": max(start + 1, end)},
        })
    r["turn_groups"] = _turn_groups(r["fragments"], high_confidence=False)
    return r


class _RoleHTMLParser(HTMLParser):
    def __init__(self, source_text: str):
        super().__init__(convert_charrefs=False)
        self.source_text = source_text
        self.line_starts = [0]
        for m in re.finditer("\n", source_text):
            self.line_starts.append(m.end())
        self.stack: list[dict[str, Any]] = []
        self.fragments: list[dict[str, Any]] = []

    def _offset(self, pos: tuple[int, int]) -> int:
        line, col = pos
        if line - 1 >= len(self.line_starts):
            return len(self.source_text)
        return self.line_starts[line - 1] + col

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        ad = {k: v for k, v in attrs}
        role = ad.get("data-message-author-role") or ad.get("data-author-role")
        if role and str(role).lower() in {"user", "assistant", "tool", "system", "developer"}:
            start = self._offset(self.getpos()) + len(self.get_starttag_text())
            self.stack.append({"tag": tag, "role": str(role).lower(), "inner_start": start, "line_start": self.getpos()[0]})

    def handle_endtag(self, tag: str) -> None:
        for idx in range(len(self.stack) - 1, -1, -1):
            item = self.stack[idx]
            if item["tag"] == tag:
                self.stack.pop(idx)
                end = self._offset(self.getpos())
                body = self.source_text[item["inner_start"]:end]
                self.fragments.append({"role": item["role"], "body": body, "line_start": item["line_start"], "line_end": self.getpos()[0]})
                break


def adapt_html(source: TextSource) -> dict[str, Any] | None:
    low = source.text[:4096].lower()
    if "<html" not in low and "<!doctype html" not in low and "data-message-author-role" not in source.text:
        return None
    p = _RoleHTMLParser(source.text)
    try:
        p.feed(source.text)
    except Exception:
        return None
    if not p.fragments:
        r = _base_report(source, "html", "partial", "medium")
        r["findings"].append({"severity": "warning", "code": "no_role_elements", "detail": "HTML was recognized, but no data-message-author-role elements were found."})
        return r
    r = _base_report(source, "html", "recognized", "high")
    for n, item in enumerate(sorted(p.fragments, key=lambda x: (x["line_start"], x["line_end"])), start=1):
        r["fragments"].append({
            "fragment_id": f"ADAPT-{n:04d}",
            "source_role": item["role"],
            "kind": "tool_result" if item["role"] == "tool" else "message",
            "timestamp": None,
            "model": None,
            "body": item["body"],
            "locator": {"line_start": item["line_start"], "line_end": item["line_end"], "html_path": f"[data-message-author-role='{item['role']}']#{n}"},
        })
    r["turn_groups"] = _turn_groups(r["fragments"], high_confidence=True)
    return r


def adapt_source(source: TextSource) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    attempts: list[dict[str, Any]] = []
    target = adapt_target_profile(source)
    if target is not None:
        attempts.append(target)
        return target, attempts

    for fn in (adapt_chatgpt_json, adapt_html, adapt_markdown, adapt_plain_text):
        result = fn(source)
        if result is not None:
            attempts.append(result)
            if result["adapter"]["status"] == "recognized":
                return result, attempts

    if attempts:
        return attempts[0], attempts
    unknown = _base_report(source, "unknown", "not_recognized", "low")
    return unknown, [unknown]


def compact_adapter_summary(adapter: dict[str, Any]) -> dict[str, Any]:
    roles: dict[str, int] = {}
    for f in adapter.get("fragments", []):
        role = f.get("source_role", "unknown")
        roles[role] = roles.get(role, 0) + 1
    return {
        "name": adapter.get("adapter", {}).get("name"),
        "status": adapter.get("adapter", {}).get("status"),
        "confidence": adapter.get("adapter", {}).get("confidence"),
        "fragment_count": len(adapter.get("fragments", [])),
        "role_counts": roles,
        "turn_group_count": len(adapter.get("turn_groups", [])),
        "finding_count": len(adapter.get("findings", [])),
    }
