from __future__ import annotations

from typing import Any

from .candidate import validate_candidate
from .common import TextSource
from .profile import expected_message_body, parse_transcript, transcript_to_report


def validate_output(text: str, candidate: dict[str, Any] | None = None, source: TextSource | None = None) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    try:
        parsed = parse_transcript(text)
    except Exception as exc:
        return {
            "report_schema": "chat-transcript-validation",
            "report_version": "1.1.0",
            "status": "invalid",
            "conversion_result": None,
            "profile": "chatgpt-markdown-transcript-v1",
            "header": {},
            "messages": {"count": 0, "prompt_count": 0, "response_count": 0},
            "candidate_binding": {"checked": candidate is not None, "match": False if candidate is not None else None},
            "findings": [{"severity": "error", "code": "structural_parse_failed", "detail": str(exc)}],
        }

    base = transcript_to_report(parsed)
    binding = {"checked": candidate is not None, "match": None}
    status = "valid"
    conversion_result = None
    if candidate is not None:
        if source is None:
            raise ValueError("source is required when candidate is provided")
        errs = validate_candidate(candidate, source, require_serializable=True)
        conversion_result = candidate.get("result")
        if errs:
            status = "binding_mismatch"
            binding["match"] = False
            findings.extend({"severity": "error", "code": "candidate_invalid", "detail": e} for e in errs)
        else:
            mismatch: list[str] = []
            conv = candidate["conversation"]
            exp_title = conv["title"]["value"]
            exp_user = conv["user"]["value"]
            exp_created = conv["created"]["value"] or "Unknown"
            exp_updated = conv["updated"]["value"] or "Unknown"
            exp_exported = conv["exported"]["value"] or "Unknown"
            exp_link = conv["link"]["value"]
            if parsed.title != exp_title: mismatch.append("title")
            if parsed.user != exp_user: mismatch.append("user")
            if parsed.created != exp_created: mismatch.append("created")
            if parsed.updated != exp_updated: mismatch.append("updated")
            if parsed.exported != exp_exported: mismatch.append("exported")
            if parsed.link_value != exp_link: mismatch.append("link")
            if len(parsed.messages) != len(candidate["messages"]):
                mismatch.append("message_count")
            else:
                for i, (pm, cm) in enumerate(zip(parsed.messages, candidate["messages"])):
                    if pm.role != cm["role"]: mismatch.append(f"message[{i}].role")
                    if pm.timestamp != (cm.get("timestamp") or "Unknown"): mismatch.append(f"message[{i}].timestamp")
                    exp_model = None if cm["role"] == "user" else (cm.get("model") or "Unknown")
                    if pm.model != exp_model: mismatch.append(f"message[{i}].model")
                    if pm.body != expected_message_body(cm): mismatch.append(f"message[{i}].body")
            if mismatch:
                status = "binding_mismatch"
                binding["match"] = False
                findings.append({"severity": "error", "code": "candidate_output_mismatch", "detail": ", ".join(mismatch)})
            else:
                binding["match"] = True

    return {
        "report_schema": "chat-transcript-validation",
        "report_version": "1.1.0",
        "status": status,
        "conversion_result": conversion_result,
        "profile": base["profile"],
        "header": base["header"],
        "messages": base["messages"],
        "candidate_binding": binding,
        "findings": findings,
    }
