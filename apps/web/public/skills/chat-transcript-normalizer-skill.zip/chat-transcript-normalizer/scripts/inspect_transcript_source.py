#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys

from _transcript.common import read_text_source, write_json_file, write_json_stdout
from _transcript.inspect import inspect_source


def main() -> int:
    ap = argparse.ArgumentParser(description="Inspect an irregular transcript source and run deterministic source adapters without making final semantic boundary decisions.")
    ap.add_argument("source")
    ap.add_argument("--pretty", action="store_true")
    ap.add_argument("--output")
    ap.add_argument("--adapter-output", help="Write the full selected source-adapter result, including recovered fragments and turn-group hints.")
    args = ap.parse_args()
    try:
        source = read_text_source(args.source)
        report, adapter = inspect_source(source)
    except UnicodeError as exc:
        report = {"report_schema":"chat-transcript-source-inspection","report_version":"1.1.0","status":"unsupported_encoding","findings":[{"severity":"error","code":"unsupported_encoding","detail":str(exc)}]}
        write_json_stdout(report, pretty=args.pretty)
        if args.output: write_json_file(args.output, report, pretty=args.pretty)
        return 3
    except ValueError as exc:
        report = {"report_schema":"chat-transcript-source-inspection","report_version":"1.1.0","status":"invalid_input","findings":[{"severity":"error","code":"invalid_input","detail":str(exc)}]}
        write_json_stdout(report, pretty=args.pretty)
        if args.output: write_json_file(args.output, report, pretty=args.pretty)
        return 3
    except OSError as exc:
        report = {"report_schema":"chat-transcript-source-inspection","report_version":"1.1.0","status":"io_error","findings":[{"severity":"error","code":"io_error","detail":str(exc)}]}
        write_json_stdout(report, pretty=args.pretty)
        if args.output: write_json_file(args.output, report, pretty=args.pretty)
        return 4
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 5
    write_json_stdout(report, pretty=args.pretty)
    if args.output:
        write_json_file(args.output, report, pretty=args.pretty)
    if args.adapter_output:
        write_json_file(args.adapter_output, adapter, pretty=args.pretty)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
