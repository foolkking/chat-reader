#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import datetime
import json
from pathlib import Path
import sys

from _transcript.candidate import validate_candidate
from _transcript.common import atomic_write_many_new, load_json, read_text_source, sha256_bytes, write_json_stdout
from _transcript.profile import render_transcript
from _transcript.validation import validate_output


def current_normalized_at() -> str:
    return datetime.now().astimezone().isoformat()


def _audit_report(candidate: dict, source, output_path: Path, normalized_at: str, validation: dict) -> dict:
    return {
        "report_schema": "chat-transcript-normalization-audit",
        "report_version": "1.0.0",
        "result": candidate["result"],
        "normalized_at": normalized_at,
        "source": {"name": source.name, "sha256": source.sha256, "byte_size": source.byte_size},
        "output": {"path": str(output_path), "message_count": len(candidate["messages"])},
        "source_accounting": candidate["source_accounting"],
        "unresolved_fragments": candidate.get("unresolved", []),
        "removed_spans": candidate.get("removed_spans", []),
        "validation": {"status": validation.get("status"), "candidate_binding": validation.get("candidate_binding")},
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Serialize a resolved or explicitly partial ConversationCandidate into ChatGPT Markdown Transcript Profile v1.")
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--source", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--audit-output", help="External audit JSON. Required automatically for PARTIAL when omitted: <output>.audit.json")
    ap.add_argument("--normalized-at", help="Normalization timestamp for the external report only; never overwrites historical Exported metadata.")
    ap.add_argument("--pretty", action="store_true")
    args = ap.parse_args()
    try:
        source = read_text_source(args.source)
        candidate = load_json(args.candidate)
        errors = validate_candidate(candidate, source, require_serializable=True)
        out_path = Path(args.output)
        if Path(args.source).resolve() == out_path.resolve():
            errors.append("output path must differ from source path")
        if out_path.exists():
            errors.append("output already exists")
        result = candidate.get("result") if isinstance(candidate, dict) else None
        audit_path = Path(args.audit_output) if args.audit_output else (Path(str(out_path) + ".audit.json") if result == "PARTIAL" else None)
        if audit_path is not None:
            if audit_path.resolve() in {out_path.resolve(), Path(args.source).resolve()}:
                errors.append("audit output path must differ from source and transcript output")
            if audit_path.exists():
                errors.append("audit output already exists")
        if errors:
            report = {
                "report_schema":"chat-transcript-serialization","report_version":"1.1.0","status":"BLOCKED",
                "findings":[{"severity":"error","code":"candidate_or_source_invalid","detail":e} for e in errors],
            }
            write_json_stdout(report, pretty=args.pretty)
            return 3

        normalized_at = args.normalized_at or current_normalized_at()
        if "\n" in normalized_at or "\r" in normalized_at or not normalized_at:
            raise ValueError("normalized-at must be a non-empty single line")
        text = render_transcript(candidate)
        validation = validate_output(text, candidate, source)
        if validation["status"] != "valid" or validation["candidate_binding"]["match"] is not True:
            report = {"report_schema":"chat-transcript-serialization","report_version":"1.1.0","status":"BLOCKED","findings":validation["findings"]}
            write_json_stdout(report, pretty=args.pretty)
            return 3

        data = text.encode("utf-8")
        audit = _audit_report(candidate, source, out_path, normalized_at, validation)
        writes: list[tuple[str | Path, bytes]] = [(out_path, data)]
        if audit_path is not None:
            audit_bytes = (json.dumps(audit, ensure_ascii=False, indent=2 if args.pretty else None, sort_keys=True, separators=None if args.pretty else (",", ":")) + "\n").encode("utf-8")
            writes.append((audit_path, audit_bytes))
        atomic_write_many_new(writes)

        candidate_raw = Path(args.candidate).read_bytes()
        report = {
            "report_schema":"chat-transcript-serialization","report_version":"1.1.0","status":result,
            "normalized_at": normalized_at,
            "source_sha256":source.sha256,"candidate_sha256":sha256_bytes(candidate_raw),
            "output":{"path":str(out_path),"sha256":sha256_bytes(data),"byte_size":len(data),"message_count":len(candidate["messages"])},
            "audit_output": str(audit_path) if audit_path is not None else None,
            "historical_exported": candidate["conversation"]["exported"]["value"],
            "findings":[],
        }
        write_json_stdout(report, pretty=args.pretty)
        return 0
    except (OSError, ValueError, UnicodeError) as exc:
        report = {"report_schema":"chat-transcript-serialization","report_version":"1.1.0","status":"BLOCKED","findings":[{"severity":"error","code":"serialization_error","detail":str(exc)}]}
        write_json_stdout(report, pretty=args.pretty)
        return 4
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 5


if __name__ == "__main__":
    raise SystemExit(main())
