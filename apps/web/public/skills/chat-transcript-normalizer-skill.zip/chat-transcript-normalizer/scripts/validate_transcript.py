#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys

from _transcript.common import load_json, read_text_source, write_json_file, write_json_stdout
from _transcript.validation import validate_output


def main() -> int:
    ap = argparse.ArgumentParser(description="Strictly validate ChatGPT Markdown Transcript Profile v1 and optional ConversationCandidate binding.")
    ap.add_argument("output")
    ap.add_argument("--candidate")
    ap.add_argument("--source")
    ap.add_argument("--pretty", action="store_true")
    ap.add_argument("--report-output")
    args = ap.parse_args()
    if bool(args.candidate) != bool(args.source):
        ap.error("--candidate and --source must be supplied together")
    try:
        target = read_text_source(args.output)
        candidate = load_json(args.candidate) if args.candidate else None
        source = read_text_source(args.source) if args.source else None
        if target.encoding != "utf-8":
            report = {
                "report_schema":"chat-transcript-validation","report_version":"1.1.0","status":"invalid","conversion_result":None,
                "profile":"chatgpt-markdown-transcript-v1","header":{},
                "messages":{"count":0,"prompt_count":0,"response_count":0},
                "candidate_binding":{"checked":candidate is not None,"match":False if candidate is not None else None},
                "findings":[{"severity":"error","code":"noncanonical_encoding","detail":"target profile requires UTF-8 without BOM"}],
            }
        else:
            report = validate_output(target.text, candidate, source)
        write_json_stdout(report, pretty=args.pretty)
        if args.report_output:
            write_json_file(args.report_output, report, pretty=args.pretty)
        return 0
    except (OSError, ValueError, UnicodeError) as exc:
        report = {"report_schema":"chat-transcript-validation","report_version":"1.1.0","status":"invalid","conversion_result":None,"profile":"chatgpt-markdown-transcript-v1","header":{},"messages":{"count":0,"prompt_count":0,"response_count":0},"candidate_binding":{"checked":bool(args.candidate),"match":False if args.candidate else None},"findings":[{"severity":"error","code":"io_or_input_error","detail":str(exc)}]}
        write_json_stdout(report, pretty=args.pretty)
        if args.report_output:
            write_json_file(args.report_output, report, pretty=args.pretty)
        return 3
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 4


if __name__ == "__main__":
    raise SystemExit(main())
