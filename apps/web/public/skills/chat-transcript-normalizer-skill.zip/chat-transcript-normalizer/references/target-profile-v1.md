# ChatGPT Markdown Transcript Profile v1

## Table of contents
1. Status and scope
2. Encoding
3. Conversation header
4. Message blocks
5. Structural boundary recognition
6. Timestamp/model rendering
7. Body preservation
8. Attachments
9. Unsupported source roles and reconstructed assistant turns
10. Pass-through
11. Validation invariants
12. Example

## 1. Status and scope

`ChatGPT Markdown Transcript Profile v1` is a project-defined transcript target modeled on the supplied reference file. It is not an official OpenAI export schema.

One file represents one conversation. The profile is for readable historical transcript interchange, not continuation state or `.context.zip` storage.

Identifier:

```text
chatgpt-markdown-transcript-v1
```

## 2. Encoding

- UTF-8 without BOM.
- LF line endings.
- No outer code fence.
- Serializer output ends with exactly one LF.
- Conversion/audit reports remain outside the transcript.

## 3. Conversation header

The file begins:

```markdown
# <title>

**User:** <user-display-name>  
**Created:** <created-display>  
**Updated:** <updated-display>  
**Exported:** <exported-display>  
**Link:** <link-display>
```

Rules:
- title: source title → filename stem → `Recovered Conversation`;
- User: source-supported value → `Anonymous`;
- Created: source-supported value → `Unknown`;
- Updated: source-supported value → `Unknown`;
- **Exported: preserve explicit source Exported metadata → otherwise `Unknown`;**
- Link: `[URL](URL)` when supported → otherwise `N/A`.

`Exported` is historical transcript metadata. Do not overwrite it with normalization time. Record normalization time externally as `normalized_at` / `Normalized At`.

Conversation metadata is not a message.

## 4. Message blocks

Target roles:

```text
user      -> Prompt
assistant -> Response
```

User:

```markdown
## Prompt:
<timestamp-or-Unknown>

<body>
```

Assistant:

```markdown
## Response:
<timestamp-or-Unknown> · <model-or-Unknown>

<body>
```

Rules:
- preserve real order;
- same-role adjacency is legal;
- do not manufacture alternation;
- do not merge genuine same-role turns merely because they are adjacent;
- each block must have a non-empty body or source-supported attachment marker.

## 5. Structural boundary recognition

An exact line containing `## Prompt:` or `## Response:` is **not sufficient** to create a structural boundary.

A target boundary is recognized only when all applicable outer signals hold:
1. exact delimiter line;
2. position outside an active fenced/literal container tracked by the parser;
3. correct metadata line immediately after it;
4. a blank line immediately after metadata;
5. for non-first messages, a structural blank line separates the preceding body from the new delimiter.

Prompt metadata must be `Unknown` or a recognized date/time display.

Response metadata must be:

```text
<recognized timestamp-or-Unknown> · <non-empty model-or-Unknown>
```

Therefore this body is legal:

```markdown
The parser discusses this literal line:
## Prompt:
not a timestamp
```

and a matching delimiter inside a fenced code block is also body content.

A literal body sequence that satisfies the complete outer-boundary signature outside a protected container remains a true representational collision. Do not silently rewrite it. Use PARTIAL or BLOCKED according to scope.

## 6. Timestamp/model rendering

- Preserve reliable source timestamp displays.
- If unavailable, render `Unknown`.
- Preserve reliable assistant model labels.
- If unavailable, render `Unknown`.
- Never infer model identity from prose style.
- Never invent historical timezone offsets.

The serializer renders candidate values; it does not reinterpret them.

## 7. Body preservation

Preserve retained historical body content, including Markdown, code, HTML, math, links, commands, errors, contradictions, and superseded plans.

Do not summarize, translate, polish, fact-correct, repair code/math, shorten, or invent body text.

For a reconstructed assistant execution turn, its final body may draw from several source fragments only when `ConversationCandidate` explicitly records the reconstruction and provenance. Meaningful tool results cannot disappear without an allowed disposition.

## 8. Attachments

Represent source-supported attachment metadata textually as:

```text
[Attachment: <filename>]
```

Place markers after retained body content in source order, separated by blank lines.

Do not duplicate a marker already retained literally in body text.

Do not fabricate bytes, local paths, URLs, filenames, or recovery claims.

## 9. Unsupported source roles and reconstructed assistant turns

The **target file** still has only Prompt/Response blocks. Source material may contain assistant/tool execution fragments.

A source `tool` fragment MAY contribute to one assistant Response when evidence shows it belongs to the same assistant execution turn, for example native branch order, call/result linkage, or a contiguous assistant/tool span bounded by the same user turn.

This reconstruction must be explicit in the candidate and preserve original fragment provenance.

A standalone source `system`, `developer`, or unrelated `tool` fragment is not silently relabeled. It may remain in an external PARTIAL audit if local; if material to transcript meaning/order, conversion is BLOCKED.

## 10. Pass-through

A source is pass-through eligible only when it already parses under this profile and no cleanup/transformation was requested.

Pass-through preserves exact bytes, including existing historical Exported metadata.

Do not regenerate a valid source merely to demonstrate normalization.

## 11. Validation invariants

A valid target file must satisfy:
1. one H1 title before transcript messages;
2. header fields `User`, `Created`, `Updated`, `Exported`, `Link` exactly once in order;
3. at least one Prompt/Response block;
4. all recognized structural blocks use the complete delimiter signature in §5;
5. Prompt metadata has a recognized timestamp or `Unknown`;
6. Response metadata has `<timestamp> · <model>`;
7. each block has body/attachment content;
8. message order equals file order;
9. literal delimiter-like body lines not satisfying the structural signature remain body;
10. conversion/audit text is not inserted as a fake message;
11. canonical serializer output ends with exactly one LF.

Structural validity alone does not prove semantic boundary or turn-reconstruction correctness.

## 12. Example

```markdown
# Planning Analysis

**User:** Anonymous  
**Created:** 9/29/2026 10:55:46  
**Updated:** 9/29/2026 15:28:36  
**Exported:** 9/29/2026 15:29:29  
**Link:** [https://chatgpt.com/c/example](https://chatgpt.com/c/example)

## Prompt:
2026/9/29 10:55:39

Please inspect the attached materials.

[Attachment: research-pack.zip]

## Response:
2026/9/29 10:55:47 · gpt-example

I inspected the supplied materials and found the first recoverable result.
```
