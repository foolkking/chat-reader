# ConversationCandidate v1.1

## Table of contents
1. Purpose
2. Top-level schema
3. Source binding
4. Conversation metadata
5. Messages
6. Turn reconstruction
7. Source fragments
8. Attachments
9. Removals
10. Unresolved fragments
11. Source accounting
12. Result semantics
13. Deterministic versus semantic fields
14. Example

## 1. Purpose

`ConversationCandidate` is the semantic intermediate representation between irregular source material and deterministic target serialization.

The model decides semantic matters such as real boundaries, roles, deletions, and turn reconstruction. Scripts validate structure, source binding, target representability, and serialization consistency.

Schema:

```text
chat-transcript-conversation-candidate
```

Version:

```text
1.1.0
```

Target:

```text
chatgpt-markdown-transcript-v1
```

## 2. Top-level schema

```json
{
  "schema": "chat-transcript-conversation-candidate",
  "schema_version": "1.1.0",
  "target_profile": "chatgpt-markdown-transcript-v1",
  "result": "NORMALIZED",
  "source": {},
  "adapter": {},
  "conversation": {},
  "messages": [],
  "removed_spans": [],
  "unresolved": [],
  "source_accounting": {}
}
```

`result` is exactly one of:

```text
NORMALIZED
PARTIAL
BLOCKED
```

## 3. Source binding

```json
{
  "source": {
    "name": "raw.md",
    "sha256": "<64 lowercase hex>",
    "byte_size": 12345,
    "encoding": "utf-8",
    "line_count": 321
  }
}
```

These fields must match the exact source passed to serializer/validator.

Optional adapter provenance:

```json
{
  "adapter": {
    "name": "chatgpt_json",
    "status": "recognized"
  }
}
```

Adapter output is evidence/navigation, not semantic authority.

## 4. Conversation metadata

```json
{
  "conversation": {
    "title": {"value": "Planning Analysis", "basis": "source_title"},
    "user": {"value": "Anonymous", "basis": "fallback_anonymous"},
    "created": {"value": "9/29/2026 10:55:46", "basis": "source_metadata"},
    "updated": {"value": "9/29/2026 15:28:36", "basis": "source_metadata"},
    "exported": {"value": "9/29/2026 15:29:29", "basis": "source_metadata"},
    "link": {"value": "https://chatgpt.com/c/example", "basis": "source_metadata"}
  }
}
```

Allowed basis values are field-specific.

Important:
- preserve explicit source `exported` metadata;
- if absent, use `value:null, basis:"unknown"`;
- never put normalization time here.

Serializer renders null Created/Updated/Exported as `Unknown`, null Link as `N/A`.

## 5. Messages

Each target Prompt/Response is one message object:

```json
{
  "candidate_id": "MSG-CAND-0001",
  "role": "assistant",
  "timestamp": "2026/9/29 10:55:47",
  "model": "gpt-example",
  "body": "Final retained body text",
  "attachments": [],
  "source_fragments": [],
  "reconstruction": {},
  "transformations": ["preserve_verbatim"]
}
```

Rules:
- `role`: `user | assistant` only;
- user `model` must be null;
- null timestamp/model renders `Unknown`;
- body preserves historical content;
- body may be empty only if source-supported attachment markers make the message non-empty;
- literal `## Prompt:`/`## Response:` lines are allowed unless they form an indistinguishable full structural delimiter signature.

## 6. Turn reconstruction

Every message includes:

```json
{
  "reconstruction": {
    "mode": "direct",
    "confidence": "high",
    "source_fragment_ids": ["SRC-0001"],
    "evidence": ["explicit_source_role"]
  }
}
```

Modes:

```text
direct
assistant_execution_turn
```

Use `assistant_execution_turn` when multiple assistant/tool source fragments belong to one conversational assistant response.

Example:

```json
{
  "role": "assistant",
  "reconstruction": {
    "mode": "assistant_execution_turn",
    "confidence": "high",
    "source_fragment_ids": ["SRC-0041", "SRC-0042", "SRC-0043", "SRC-0044"],
    "evidence": [
      "native_branch_order",
      "contiguous_non_user_execution_span",
      "tool_call_result_linkage"
    ]
  }
}
```

For `assistant_execution_turn`:
- final target role must be assistant;
- source fragment roles may be assistant/tool only;
- at least two source fragments are required;
- at least one source fragment must be assistant;
- meaningful tool payload must have an explicit retained/support/removal disposition.

Do not use reconstruction to hide unrelated standalone tool/system/developer content.

## 7. Source fragments

Every retained target message keeps original provenance:

```json
{
  "fragment_id": "SRC-0042",
  "adapter_fragment_id": "ADAPT-0042",
  "source_role": "tool",
  "kind": "tool_result",
  "contribution": "support",
  "locator": {
    "json_pointer": "/mapping/node-42/message"
  }
}
```

Allowed source roles:

```text
user assistant tool system developer unknown
```

Allowed kinds:

```text
message body progress tool_call tool_result metadata attachment wrapper other
```

Contribution:

```text
retained_body
support
removed_runtime
```

Locator must contain at least one supported location form:
- `line_start` + `line_end` (1-based inclusive);
- `char_start` + `char_end` (0-based half-open);
- `json_pointer`;
- `html_path`.

`reconstruction.source_fragment_ids` must exactly cover the message's `source_fragments`.

## 8. Attachments

```json
{
  "filename": "research-pack.zip",
  "basis": "source_attachment_metadata",
  "source_order": 1
}
```

Basis:

```text
source_attachment_metadata
source_body_marker
```

Do not duplicate an attachment marker already retained literally in body text.

## 9. Removals

Justified removed spans are external accounting records:

```json
{
  "removal_id": "REM-0001",
  "locator": {"line_start": 90, "line_end": 93},
  "reason": "runtime_noise",
  "confidence": "high"
}
```

Allowed reasons:

```text
runtime_noise
transport_duplicate
empty_shell
source_wrapper
unsupported_nonconversation_metadata
other
```

Do not use removal records for uncertain material; use `unresolved`.

## 10. Unresolved fragments

```json
{
  "issue_id": "UNRES-0001",
  "kind": "unsupported_role",
  "description": "Independent developer message cannot be represented in target v1.",
  "impact": "local",
  "disposition": "external_audit",
  "excerpt": "Developer: ...",
  "locator": {"line_start": 201, "line_end": 204}
}
```

Kinds:

```text
boundary role order branch version missing_body unsupported_role representation tool_linkage other
```

Impact:

```text
local
material
```

Disposition:

```text
external_audit
blocks_conversion
```

Rules:
- PARTIAL unresolved items must be `impact=local` and `disposition=external_audit`;
- BLOCKED requires at least one material or blocking unresolved item;
- excerpt is optional and capped at 2000 characters;
- unresolved content is never inserted as a fake transcript message.

## 11. Source accounting

```json
{
  "source_accounting": {
    "complete": true,
    "resolution_status": "PARTIAL",
    "confirmed_message_count": 101,
    "retained_message_count": 99,
    "whole_messages_removed": 1,
    "unresolved_message_count": 1,
    "removed_span_count": 3,
    "transport_duplicate_count": 1,
    "unresolved_count": 2,
    "limitations": ["one local developer fragment is audit-only"]
  }
}
```

`complete=true` means every accessible source region has a disposition. It does not mean every ambiguity is resolved.

Count invariant:

```text
confirmed_message_count
= retained_message_count
+ whole_messages_removed
+ unresolved_message_count
```

`unresolved_count` may exceed `unresolved_message_count` because some unresolved issues concern a span or representation rather than a confirmed whole message.

## 12. Result semantics

### NORMALIZED

Require:
- non-empty messages;
- `source_accounting.complete=true`;
- `resolution_status=NORMALIZED`;
- `unresolved=[]`.

### PARTIAL

Require:
- at least one retained message;
- complete source accounting;
- `resolution_status=PARTIAL`;
- at least one unresolved item;
- all unresolved items local + external audit.

Serializer may emit the confirmed transcript plus external audit JSON.

### BLOCKED

Require at least one material/blocking unresolved issue.

A BLOCKED candidate is not serializable.

## 13. Deterministic versus semantic fields

Semantic/model-owned:
- source fragment interpretation;
- real message boundaries and roles;
- direct versus reconstructed turn identity;
- which payload is retained/support/runtime noise;
- metadata provenance basis;
- removal justification;
- unresolved impact;
- NORMALIZED/PARTIAL/BLOCKED choice.

Deterministic/script-owned:
- source hash/size/encoding/line-count verification;
- schema validation;
- source locator bounds;
- count reconciliation;
- target delimiter representability;
- Markdown serialization;
- normalization timestamp in report;
- target reparse and candidate binding.

## 14. Example

```json
{
  "schema": "chat-transcript-conversation-candidate",
  "schema_version": "1.1.0",
  "target_profile": "chatgpt-markdown-transcript-v1",
  "result": "NORMALIZED",
  "source": {
    "name": "raw.txt",
    "sha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    "byte_size": 100,
    "encoding": "utf-8",
    "line_count": 8
  },
  "adapter": {"name": "plain_text", "status": "recognized"},
  "conversation": {
    "title": {"value": "raw", "basis": "source_filename"},
    "user": {"value": "Anonymous", "basis": "fallback_anonymous"},
    "created": {"value": null, "basis": "unknown"},
    "updated": {"value": null, "basis": "unknown"},
    "exported": {"value": null, "basis": "unknown"},
    "link": {"value": null, "basis": "unknown"}
  },
  "messages": [
    {
      "candidate_id": "MSG-CAND-0001",
      "role": "user",
      "timestamp": null,
      "model": null,
      "body": "hello",
      "attachments": [],
      "source_fragments": [
        {
          "fragment_id": "SRC-0001",
          "adapter_fragment_id": "ADAPT-0001",
          "source_role": "user",
          "kind": "message",
          "contribution": "retained_body",
          "locator": {"line_start": 1, "line_end": 2}
        }
      ],
      "reconstruction": {
        "mode": "direct",
        "confidence": "high",
        "source_fragment_ids": ["SRC-0001"],
        "evidence": ["explicit_source_role"]
      },
      "transformations": ["role_normalization"]
    }
  ],
  "removed_spans": [],
  "unresolved": [],
  "source_accounting": {
    "complete": true,
    "resolution_status": "NORMALIZED",
    "confirmed_message_count": 1,
    "retained_message_count": 1,
    "whole_messages_removed": 0,
    "unresolved_message_count": 0,
    "removed_span_count": 0,
    "transport_duplicate_count": 0,
    "unresolved_count": 0,
    "limitations": []
  }
}
```
