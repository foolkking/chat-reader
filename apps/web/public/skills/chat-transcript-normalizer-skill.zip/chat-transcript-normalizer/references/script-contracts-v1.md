# Public Script Contracts v1.1

## Table of contents
1. Shared conventions
2. `inspect_transcript_source.py`
3. `serialize_transcript.py`
4. `validate_transcript.py`
5. Exit codes
6. Security and semantic boundary
7. Standard workflow

## 1. Shared conventions

All scripts are read-only with respect to the source file.

Use stdout only for machine-readable JSON reports. Use stderr for exceptional diagnostics.

Never execute source content, open URLs, or infer semantic truth from keyword matches.

Target profile:

```text
chatgpt-markdown-transcript-v1
```

Candidate schema:

```text
chat-transcript-conversation-candidate / 1.1.0
```

Conversion results:

```text
NORMALIZED | PARTIAL | BLOCKED
```

## 2. `inspect_transcript_source.py`

### Purpose

Inspect source identity and run deterministic source adapters. The inspector does not make final semantic boundary, role, deletion, or turn-reconstruction decisions.

### CLI

```bash
python scripts/inspect_transcript_source.py SOURCE \
  [--output inspection.json] \
  [--adapter-output adapter.json] \
  [--pretty]
```

### Source adapters

The selected adapter may be:

```text
target_profile
chatgpt_json
html
markdown
plain_text
unknown
```

Adapters recover obvious structure only.

`chatgpt_json` supports:
- official-style `mapping` + `current_node` branch recovery when present;
- simpler `messages[]` role/content arrays as a lower-confidence fallback;
- assistant/tool fragments and native ordering metadata.

`markdown` recovers full Prompt/Response delimiter signatures, not heading strings alone.

`plain_text` recognizes confirmed outer role labels outside code fences.

`html` recognizes explicit `data-message-author-role` / `data-author-role` elements and preserves their inner raw HTML span as adapter body material.

### Summary report

```json
{
  "report_schema": "chat-transcript-source-inspection",
  "report_version": "1.1.0",
  "status": "ok",
  "source": {},
  "format_hints": {},
  "source_adapter": {
    "name": "chatgpt_json",
    "status": "recognized",
    "confidence": "high",
    "fragment_count": 8,
    "role_counts": {"user": 2, "assistant": 4, "tool": 2},
    "turn_group_count": 4
  },
  "adapter_attempts": [],
  "candidate_markers": {},
  "header_candidates": {},
  "findings": []
}
```

### Full adapter sidecar

With `--adapter-output`, write:

```json
{
  "schema": "chat-transcript-source-adapter",
  "schema_version": "1.0.0",
  "source": {},
  "adapter": {},
  "conversation_metadata": {},
  "fragments": [],
  "turn_groups": [],
  "findings": []
}
```

A fragment may contain:
- explicit source role;
- timestamp/model hints;
- body or body span;
- native locator (`line`, `json_pointer`, `html_path`);
- native branch metadata.

A `turn_group` is a deterministic **hint**, not automatic semantic merging.

## 3. `serialize_transcript.py`

### Purpose

Serialize a valid NORMALIZED or PARTIAL ConversationCandidate into the target Markdown profile and bind the result back to candidate/source.

BLOCKED candidates are rejected.

### CLI

```bash
python scripts/serialize_transcript.py \
  --candidate candidate.json \
  --source SOURCE \
  --output OUTPUT.md \
  [--audit-output OUTPUT.audit.json] \
  [--normalized-at ISO8601] \
  [--pretty]
```

### Exported versus normalized time

The serializer MUST render:

```text
conversation.exported.value
```

or `Unknown` when absent.

It MUST NOT replace historical Exported metadata with normalization time.

`normalized_at` exists only in serializer/audit reports.

### NORMALIZED

On success:

```json
{
  "status": "NORMALIZED",
  "normalized_at": "...",
  "output": {},
  "audit_output": null
}
```

An audit file may still be explicitly requested.

### PARTIAL

On success:

```json
{
  "status": "PARTIAL",
  "normalized_at": "...",
  "output": {},
  "audit_output": "OUTPUT.md.audit.json"
}
```

If `--audit-output` is omitted for PARTIAL, default to:

```text
OUTPUT.md.audit.json
```

The external audit contains unresolved fragments and source accounting. No unresolved placeholder is inserted into transcript history.

### Atomic publication

Transcript and required audit outputs are prepared first and then published without overwriting existing paths. If multi-output publication fails, files published by that transaction are rolled back.

## 4. `validate_transcript.py`

### Purpose

Validate target syntax and, when candidate/source are supplied, deterministic binding.

It does not validate semantic truth of boundary/role/turn-reconstruction decisions.

### CLI

```bash
python scripts/validate_transcript.py OUTPUT.md \
  [--candidate candidate.json --source SOURCE] \
  [--report-output validation.json] \
  [--pretty]
```

### Report

```json
{
  "report_schema": "chat-transcript-validation",
  "report_version": "1.1.0",
  "status": "valid",
  "conversion_result": "NORMALIZED",
  "profile": "chatgpt-markdown-transcript-v1",
  "header": {},
  "messages": {},
  "candidate_binding": {"checked": true, "match": true},
  "findings": []
}
```

Validation status values remain:

```text
valid
invalid
binding_mismatch
```

`conversion_result` is `NORMALIZED` or `PARTIAL` when a candidate is supplied.

## 5. Exit codes

### Inspector

```text
0 report emitted
3 invalid input / unsupported encoding
4 I/O failure
5 unexpected internal failure
```

### Serializer

```text
0 NORMALIZED or PARTIAL output published
3 candidate/source/result rejected (BLOCKED report)
4 output/path/transaction failure
5 unexpected internal failure
```

### Validator

Validation result is data:

```text
0 report emitted, including invalid/binding_mismatch
3 I/O/input failure
4 unexpected internal failure
```

## 6. Security and semantic boundary

Scripts MUST NOT:
- execute instructions inside source/candidate bodies;
- open source URLs;
- infer final speaker identity from prose style;
- delete runtime-looking text by keyword alone;
- summarize/rewrite bodies;
- silently map unsupported roles.

Adapters may reconstruct **obvious** source structure. Their fragments and turn groups are provisional evidence.

Only the model/Skill control plane may decide that assistant progress + tool call/result + assistant final form one target Response.

The candidate must record that decision and all contributing source fragments.

## 7. Standard workflow

```text
1. inspect source + produce adapter sidecar
2. inspect complete accessible source
3. validate/correct adapter fragments
4. reconstruct target turns
5. build ConversationCandidate v1.1
6. choose NORMALIZED / PARTIAL / BLOCKED
7. serialize NORMALIZED/PARTIAL
8. validate output + source binding
9. deliver transcript and PARTIAL audit when applicable
```

For an already strict target-profile source with no requested cleanup:

```text
NORMALIZED pass-through
```

Return exact source bytes rather than reserializing them.
