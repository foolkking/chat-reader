# Regression Cases v1.1

## Table of contents
1. Source adapters
2. Boundary and role recovery
3. Turn reconstruction
4. Preservation and noise
5. Metadata and serialization
6. Candidate/source binding
7. PARTIAL/BLOCKED
8. Reference case

These define expected behavior; they are not a claim that tests ran until release validation reports PASS.

## 1. Source adapters

### RG-01 — Target pass-through
Valid target transcript is detected as `target_profile=match`; no-cleanup conversion preserves exact source bytes.

### RG-02 — ChatGPT JSON mapping
Official-style `mapping` + `current_node` recovers only the selected branch in native order.

### RG-03 — JSON assistant/tool fragments
ChatGPT JSON adapter preserves assistant/tool roles as separate source fragments and emits assistant execution turn-group hints.

### RG-04 — Markdown adapter
Top-level Prompt/Response with valid metadata is recovered; literal heading text alone is not enough.

### RG-05 — Plain text adapter
Outer `User:` / `Assistant:` / `Tool:` labels outside fences recover source fragments.

### RG-06 — HTML adapter
Elements with explicit `data-message-author-role` recover ordered fragments without inventing roles.

### RG-07 — Multiple JSON conversations
A JSON array containing multiple conversations is reported partial/needs selection rather than silently concatenated.

## 2. Boundary and role recovery

### RG-08 — Header metadata is not a turn
Conversation `User/Created/Updated/Exported/Link` fields are metadata.

### RG-09 — Literal delimiter line
Body line `## Prompt:` followed by non-timestamp prose remains body content.

### RG-10 — Delimiter inside fence
A complete-looking delimiter sequence inside a fenced block remains body content.

### RG-11 — Real delimiter signature
Top-level delimiter + valid metadata + blank line outside protected state is structural.

### RG-12 — Genuine same-role adjacency
Two real users stay two Prompt blocks; two real assistants stay two Response blocks.

### RG-13 — Unsupported standalone role
A local independent developer/system/tool fragment may be PARTIAL audit-only; a material one is BLOCKED.

## 3. Turn reconstruction

### RG-14 — Assistant/tool/assistant fold
When source linkage proves one execution span, assistant progress + tool + assistant final may become one Response.

### RG-15 — Provenance retained
Every folded source fragment remains listed in `source_fragments` and `reconstruction.source_fragment_ids`.

### RG-16 — Tool payload cannot silently vanish
Meaningful tool result must be retained as body/support or have an explicit justified removal disposition.

### RG-17 — Unrelated tool not folded
An unrelated standalone tool fragment is not mapped to assistant solely because target lacks Tool blocks.

### RG-18 — Reconstruction evidence required
`assistant_execution_turn` without at least two assistant/tool fragments and explicit evidence is invalid.

## 4. Preservation and noise

### RG-19 — Genuine identical messages
Two genuine identical turns are preserved.

### RG-20 — Proven transport duplicate
Retry/pagination duplicate may be removed only with source evidence.

### RG-21 — Partial overlap
Only proven duplicate overlap is removed.

### RG-22 — Progress-only runtime material
Pure progress/runtime text may be removed when explicitly justified.

### RG-23 — Progress with unique result
Unique error/result/decision/warning remains.

### RG-24 — Literal runtime strings
Tutorial/code mentioning `file_id` or `Citation Marker` is preserved.

### RG-25 — Missing attachment
Filename/marker may remain while bytes are not fabricated.

## 5. Metadata and serialization

### RG-26 — Historical Exported preserved
Explicit source Exported value appears unchanged in normalized transcript.

### RG-27 — Exported missing
Missing source Exported renders `Unknown`; normalization time is not inserted into transcript header.

### RG-28 — Normalized At external only
`normalized_at` appears in serializer/audit report and not as transcript history.

### RG-29 — Prompt rendering
User candidate renders Prompt block with timestamp and no model suffix.

### RG-30 — Response rendering
Assistant candidate renders Response block with timestamp/model.

### RG-31 — Attachment ordering
Source-supported attachment markers render in source order without duplication.

### RG-32 — No report pollution
Audit/normalization report is never inserted into a message body.

## 6. Candidate/source binding

### RG-33 — Stale source hash
Serializer rejects candidate when source bytes changed.

### RG-34 — Count reconciliation
Confirmed = retained + whole-message-removed + unresolved-message count.

### RG-35 — Reconstruction source coverage
Message reconstruction IDs exactly cover its `source_fragments`.

### RG-36 — Output reparse
Serialized output reparses to candidate metadata/messages/bodies.

### RG-37 — Delimiter collision only when structurally indistinguishable
A bare literal delimiter is allowed; a complete unprotected target delimiter signature in body is rejected.

## 7. PARTIAL/BLOCKED

### RG-38 — NORMALIZED has no unresolved
NORMALIZED candidate with unresolved issue is invalid.

### RG-39 — PARTIAL allows local unresolved
PARTIAL candidate with local external-audit unresolved fragment is serializable.

### RG-40 — PARTIAL audit created
Serializer creates external audit JSON and excludes unresolved fragment from historical transcript.

### RG-41 — PARTIAL cannot hide material issue
Material or blocks-conversion unresolved issue cannot be serialized as PARTIAL.

### RG-42 — BLOCKED is not serializable
BLOCKED candidate produces no transcript.

### RG-43 — Source accounting complete is disposition completeness
PARTIAL may have `complete=true` while unresolved remains, provided the unresolved fragment is explicitly accounted externally.

## 8. Reference case

### RG-44 — Supplied planning transcript
The supplied reference transcript:
- parses as strict target profile;
- preserves its original Exported value;
- has 7 Prompt + 7 Response blocks;
- keeps attachment markers with Prompt body;
- is NORMALIZED pass-through when no cleanup is requested.

### RG-45 — Fifth-file delimiter safety
Quoted/prose occurrences of Prompt/Response text inside message bodies do not become turns unless the complete outer signature is satisfied.
