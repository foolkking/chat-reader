from __future__ import annotations

import re
from pathlib import PurePosixPath

_DRIVE_RE = re.compile(r"^[A-Za-z]:")


def normalize_member_name(name: str) -> str:
    return name.replace("\\", "/")


def is_safe_member_name(name: str) -> bool:
    norm = normalize_member_name(name)
    if not norm or norm.startswith("/") or _DRIVE_RE.match(norm):
        return False
    parts = PurePosixPath(norm).parts
    return all(part not in {"..", ""} for part in parts)


def safe_materialized_filename(name: str | None, fallback: str = "attachment.bin") -> str:
    if not name:
        return fallback
    norm = normalize_member_name(name)
    base = PurePosixPath(norm).name
    if not base or base in {".", ".."}:
        base = fallback
    # Keep readable Unicode, remove filesystem separators/control-ish chars.
    base = base.replace("/", "_").replace("\\", "_")
    base = "".join(ch if ord(ch) >= 32 else "_" for ch in base)
    return base or fallback
