from __future__ import annotations

import json
from typing import Any

from .model import PackageManifestInfo
from .source import PackageSource, PackageError


def load_package_manifest(source: PackageSource) -> PackageManifestInfo:
    try:
        raw = json.loads(source.read_text("manifest.json"))
    except Exception as e:
        raise PackageError(f"manifest.json is unreadable: {e}") from e
    if not isinstance(raw, dict):
        raise PackageError("manifest.json must contain a JSON object")
    entrypoint = raw.get("entrypoint")
    entrypoint_source = "manifest"
    if not isinstance(entrypoint, str) or not entrypoint:
        if source.exists("conversation.canjsonl"):
            entrypoint = "conversation.canjsonl"
            entrypoint_source = "legacy_fallback"
        else:
            raise PackageError("manifest entrypoint is missing and no legacy conversation.canjsonl exists")
    return PackageManifestInfo(
        raw=raw,
        format=raw.get("format"),
        format_version=str(raw.get("format_version")) if raw.get("format_version") is not None else None,
        entrypoint=entrypoint,
        entrypoint_source=entrypoint_source,
        conversation=raw.get("conversation") if isinstance(raw.get("conversation"), dict) else {},
        conversation_completeness=raw.get("conversation_completeness"),
        asset_completeness=raw.get("asset_completeness"),
        attachments=raw.get("attachments") if isinstance(raw.get("attachments"), dict) else {},
        included_content=raw.get("included_content") if isinstance(raw.get("included_content"), dict) else {},
        files=raw.get("files") if isinstance(raw.get("files"), dict) else {},
        continuation=raw.get("continuation") if isinstance(raw.get("continuation"), dict) else None,
    )
