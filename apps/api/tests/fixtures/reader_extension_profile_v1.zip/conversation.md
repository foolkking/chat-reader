# Tide contract

## User

一条潮汐记录

## Assistant

```md
## User
```

[report](assets/report.csv)

## Assistant

Formula $x^2$

